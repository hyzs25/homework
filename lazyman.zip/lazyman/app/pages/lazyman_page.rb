#encoding: utf-8

class LazymanPage < Lazyman::Page
end
