#encoding: utf-8

class LazymanNavigator < Lazyman::Navigator
end
