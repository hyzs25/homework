module Menu
	include PageObject
	link 'main', text: 'Main'
	link 'logout', text: 'Logout'
	link 'report_issue', text: 'Report Issue'
end
