#encoding: utf-8
class GoogleSearchResultPage < LazymanPage
	h3 'first_result', index: 0
end
